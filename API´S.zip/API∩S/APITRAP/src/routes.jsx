import { BrowserRouter, Route, Routes } from 'react-router-dom'
import CARD from '../src/CARD/index'
import TRAP from './TRAP/index'


function AppRoutes() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={ <PageBase /> }>
                    <Route path="/funk" element={ <TRAP /> }></Route>
                    <Route path="/card" element={ <CARD /> }></Route>
                </Route>
            </Routes>
        </BrowserRouter>
    )
}

export default AppRoutes