import TRAP from '../TRAP/index'
import CARD from '../CARD/index'
import { Outlet } from 'react-router-dom'


function PageBase() {
    return (
        <main>
            <TRAP />
            <CARD />
            <Outlet />
        </main>
    )
}

export default PageBase