import { useState } from 'react'
import './App.css'
import CARD from '../src/CARD/index'
import TRAP from './TRAP'


function App() {
    const [trap, SetTrap] = useState([]) // permite retinrar um array e seu resultado

function btnClick() {
  console.log(trap);
}

  return (
    <>
    <h1>MUSICA</h1>
    <CARD />
    <TRAP />
    <button onClick={btnClick}>Clique </button>
    </> 
  )
}

export default App
