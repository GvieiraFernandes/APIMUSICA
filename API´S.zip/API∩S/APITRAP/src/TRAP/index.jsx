import { useEffect, useState } from 'react'
import styles from './trap.css'
import Card from '../CARD/index'

//função principal, só é iniciada apos ser chamada
function TRAP() {
    const [trap, SetTrap] = useState([]) // permite retinrar um array e seu resultado

    useEffect(() => { //useEffect busca dados
        const buscarTrap = async () => { //Async
            const response = await fetch('https://raw.githubusercontent.com/AnnaJulyaVieira/ApiMusica/main/trap.json') //fetch acessa API
            const api = await response.json()
            SetTrap(api)
        }
        buscarTrap()
    }, [])

    //Retornar dados do json 
    return (
        <section className={styles.trap}>
            <h2>PLAYLIST TRAP</h2>
            {
                trap.length > 0 ? (
                    <section className={styles.lista}>
                        {
                            trap.map((repo) => (
                                <Card
                                    nome_da_musica={repo.nome_da_musica}
                                    cantor={repo.cantor}
                                    ritmo={repo.ritmo}
                                    img={repo.img}
                                    album={repo.album}
                                />
                            ))
                        }
                    </section>
                ) : (
                    <p>Selecione a Música</p>
                )
            }
        </section>
    )
}

export default TRAP