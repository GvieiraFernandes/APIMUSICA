import { useState } from 'react'
import './App.css'
import CARD from '../src/CARD/index'
import RAP from '../src/RAP/index'


function App() {
    const [rap, SetRap] = useState([]) // permite retinrar um array e seu resultado

function btnClick() {
  console.log(rap);
}

  return (
    <>
    <h1>MUSICA</h1>
    <CARD />
    <RAP />
    <button onClick={btnClick}>Clique </button>
    </> 
  )
}

export default App
