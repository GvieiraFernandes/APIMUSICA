import { useEffect, useState } from 'react'
import styles from './funk.css'
import Card from '../CARD/index'

//função principal, só é iniciada apos ser chamada
function FUNK() {
    const [funk, SetFunk] = useState([]) // permite retinrar um array e seu resultado

    useEffect(() => { //useEffect busca dados
        const buscarFunk = async () => { //Async
            const response = await fetch('https://raw.githubusercontent.com/AnnaJulyaVieira/ApiMusica/main/funk.json') //fetch acessa API
            const api = await response.json()
            SetFunk(api)
        }
        buscarFunk()
    }, [])

    //Retornar dados do json 
    return (
        <section className={styles.funk}>
            <h2>PLAYLIST FUNK</h2>
            {
                funk.length > 0 ? (
                    <section className={styles.lista}>
                        {
                            funk.map((repo) => (
                                <Card
                                    nome_da_musica={repo.nome_da_musica}
                                    cantor={repo.cantor}
                                    ritmo={repo.ritmo}
                                    img={repo.img}
                                    album={repo.album}
                                />
                            ))
                        }
                    </section>
                ) : (
                    <p>Selecione a Música</p>
                )
            }
        </section>
    )
}

export default FUNK