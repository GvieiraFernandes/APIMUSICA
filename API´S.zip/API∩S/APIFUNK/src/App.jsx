import { useState } from 'react'
import './App.css'
import CARD from '../src/CARD/index'
import RAP from './FUNK/index'


function App() {
    const [funk, SetRap] = useState([]) // permite retinrar um array e seu resultado

function btnClick() {
  console.log(funk);
}

  return (
    <>
    <h1>MUSICA</h1>
    <CARD />
    <RAP />
    <button onClick={btnClick}>Clique </button>
    
    </> 
  )
}

export default App
