import FUNK from '../FUNK/index'
import CARD from '../CARD/index'
import { Outlet } from 'react-router-dom'

function PageBase() {
    return (
        <main>
            <FUNK />
            <CARD />
            <Outlet />
        </main>
    )
}

export default PageBase