import RAP from '../RAP/index'
import CARD from '../CARD/index'
import { Outlet } from 'react-router-dom'

function PageBase() {
    return (
        <main>
            <RAP />
            <CARD />
            <Outlet />
        </main>
    )
}

export default PageBase