import { BrowserRouter, Route, Routes } from 'react-router-dom'
import CARD from '../src/CARD/index'
import RAP from '../src/RAP/index'


function AppRoutes() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={ <PageBase /> }>
                    <Route path="/rap" element={ <RAP /> }></Route>
                    <Route path="/card" element={ <CARD /> }></Route>
                </Route>
            </Routes>
        </BrowserRouter>
    )
}

export default AppRoutes