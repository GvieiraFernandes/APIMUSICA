import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import CARD from '../src/CARD/index'
import RAP from '../src/RAP/index'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>

    <h1>MUSICA</h1>
    <CARD />
    <RAP />
    
    </> 
  )
}

export default App
