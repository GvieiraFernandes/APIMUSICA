import { useEffect, useState } from 'react'
import styles from './rap.css'
import Card from '../CARD/index'

//função principal, só é iniciada apos ser chamada
function RAP() { 
const [ rap, SetRap ] = useState([]) // permite retinrar um array e seu resultado

useEffect(() => { //useEffect busca dados
const buscarRap = async () => { //Async
const response = await fetch('https://github.com/AnnaJulyaVieira/ApiMusica/blob/main/apimusica/rap.json') //fetch acessa API
const api = await response.json()
SetRap(api)
}
buscarRap()
},[])
 
//Retornar dados do json 
return (
    <section className={styles.rap}>
        <h2>PLAYLIST</h2>
        {
            rap.length > 0 ? (
                <section className={styles.lista}>
                    {
                        rap.map((repo) => (
                            <Card
                            nome_da_musica={repo.nome_da_musica}
                                cantor={repo.cantor}
                                ritmo={repo.ritmo}
                                img={repo.img}
                                album={repo.album}
                            />
                        ))
                    }
                </section>
            ) : (
                <p>Selecione a Música</p>
            )
        }
    </section>
)
}

export default RAP