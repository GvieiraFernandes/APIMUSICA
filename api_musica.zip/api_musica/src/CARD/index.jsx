import styles from './card.css'

import { Link } from 'react-router-dom'


function Card({nome_da_musica, cantor, ritmo, img, album }) {
    return (
        <section className={styles.card}>
            <h3>{nome_da_musica}</h3>
            <p>{cantor}</p>
            <p>{ritmo}</p>
            <p>{img}</p>
            <p>{album}</p>

                <Link to={html_url} className={styles.botao}>
                    <BsArrowRight />
                </Link>
        </section>
    )
}

export default Card





